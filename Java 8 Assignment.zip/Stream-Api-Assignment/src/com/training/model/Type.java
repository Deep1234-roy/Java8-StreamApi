package com.training.model;

public enum Type {
	MEAT,FISH,OTHER;
}
