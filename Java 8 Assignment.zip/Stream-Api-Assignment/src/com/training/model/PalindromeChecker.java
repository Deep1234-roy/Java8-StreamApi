package com.training.model;

@FunctionalInterface
public interface PalindromeChecker {
	public boolean isPalindrome(String str);
	

}
